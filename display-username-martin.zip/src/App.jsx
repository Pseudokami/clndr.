// src/App.jsx
import React from 'react';
import Header from './components/Header';
import Calendar from './components/Calendar';
import './index.css';
import './App.css';

function App() {
  const username = 'Guest'; 

  return (
    <div className="app-wrapper">
      <Header username={username} />
      <main className="calendar-wrapper">
        <Calendar />
      </main>
    </div>
  );
}

export default App;
