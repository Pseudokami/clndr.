import React from "react";
import "./Sidebar.css";

const Sidebar = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handleOverlayClick = (e) => {
    // Close only if user clicks outside the sidebar
    if (e.target.classList.contains("sidebar-overlay")) {
      onClose();
    }
  };

  return (
    <div className="sidebar-overlay" onClick={handleOverlayClick}>
      <div className="sidebar open">
        <button className="close-btn" onClick={onClose}>×</button>
        <div className="sidebar-content">
          <img src="/account_circle.png" alt="Profile" className="sidebar-profile-icon" />
          <a href="/authPage.html" className="sidebar-login-link">Login</a>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
