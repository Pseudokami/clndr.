// src/components/Calendar.jsx
import React, { useState } from 'react';
import FullCalendar from '@fullcalendar/react'; // must be before plugins
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction'; // needed for interaction
import timeGridPlugin from '@fullcalendar/timegrid';


export default function Calendar() {
  const [events, setEvents] = useState([
    { id: '1', title: 'Sample Event', date: '2025-05-10' }
  ]);

  // Add event on date click
  const handleDateClick = (arg) => {
    const title = prompt('Enter event title:');
    if (title) {
      setEvents([
        ...events,
        { id: String(events.length + 1), title, date: arg.dateStr }
      ]);
    }
  };

  // Remove event on event click (confirm before deleting)
  const handleEventClick = (clickInfo) => {
    if (
      window.confirm(
        `Delete event '${clickInfo.event.title}' on ${clickInfo.event.startStr}?`
      )
    ) {
      setEvents(events.filter((e) => e.id !== clickInfo.event.id));
    }
  };

  return (
    <div className="calendar-container">
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        initialDate="2025-05-01"
        fixedWeekCount={true}
        headerToolbar={{
          left: '',
          center: 'dayGridMonth,timeGridWeek,timeGridDay',
          right: ''
        }}
        height="auto"
        events={events}
        dateClick={handleDateClick}
        eventClick={handleEventClick}
        selectable={true}
        editable={true}
      />
    </div>
  );
}
