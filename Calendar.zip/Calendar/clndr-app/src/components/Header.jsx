import React from 'react';
import '../index.css';

const Header = () => {
  return (
    <header>
      <img className="clndr" src="/Clndr..png" alt="Logo" />

      <div className="accountDisplay">
        <div className="userPlaceholder">
          <div className="userBox"></div>
          <div className="userText">Guest</div>
        </div>
        <img className="account_icon" src="/account_circle.png" alt="Account Icon" />
      </div>
    </header>
  );
};

export default Header;
