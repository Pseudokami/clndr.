import React from 'react';
import Header from './components/Header';
import Calendar from './components/Calendar';
import './index.css';
import './App.css'; // Optional if you want global styles for layout

function App() {
  return (
    <div className="app-wrapper">
      <Header />
      <main className="calendar-wrapper">
        <Calendar />
      </main>
    </div>
  );
}

export default App;
